using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using Bitmex;
using Bitmex.Models;


namespace func_rbk_test_dev_back
{
    public class Df_RunBot_BitmexWebSocket_Act
    {
        private IBitmexAuthorization _bitmexAuthorization;
        private IBitmexApiSocketService _bitmexApiSocketService;
        private bool _isConnected;
        
        // Collections for storing incoming exchange data
        Dictionary<string, InstrumentModel> InstrumentDictionary { get; }

        // Properties
        public bool IsConnected
        {
            get { return _isConnected; }
            set
            {
                _isConnected = value;
            }
        }

        // Constructor
        public Df_RunBot_BitmexWebSocket_Act()
        {
            InstrumentDictionary = new Dictionary<string, InstrumentModel>();
        }

        // Run
        [FunctionName(nameof(Df_RunBot_BitmexWebSocket_Act))]
        public async Task<string> RunActivity([ActivityTrigger] DurableActivityContext context, ILogger log)
        {
            log.LogInformation($"Executing {0}", nameof(Df_RunBot_BitmexWebSocket_Act));

            // Extract the input values.
            var (key, secret, bitmexEnvironment) = context.GetInput<(string, string, string)>();

            // Test Environment
            BitmexEnvironment environment;
            if (bitmexEnvironment == "Test")
            {
                environment = BitmexEnvironment.Test;
            }
            else if (bitmexEnvironment == "Prod")
            {
                environment = BitmexEnvironment.Prod;
            }
            else
            {
                throw new ArgumentException("Invalid value bitmexEnvironment parameter.");
            }


            // ***Trace 10
            // BitmexAuthorization = class under Bitmex
            // BitmexEnvironment.Test = enum under Models > BitmexEnvironment
            _bitmexAuthorization = new BitmexAuthorization
            {
                BitmexEnvironment = environment,
                Key = key,
                Secret = secret
            };

            // ***Trace 30
            // Connect via WebSocket
            // BitmexApiSocketService = class under Bitmex
            _bitmexApiSocketService = BitmexApiSocketService.CreateDefaultApi(_bitmexAuthorization);

            // ***Trace 120
            // ***Trace 130

            // Subscribe to different kinds of data messages received from the exchange
            await StartLoad(log);

            string msg = "OK";
            log.LogInformation("Activity function exiting.");
            return msg ?? "No text was received in the response.";
        }

        // ***Trace 140
        private async Task<string> StartLoad(ILogger log)
        {
            try
            {
                IsConnected = _bitmexApiSocketService.Connect();
                // ***Trace 290
            }
            catch (Exception e)
            {
                string message = "Error trying to connect to Bitmex via WS: " + e.Message;
                throw new Exception(message);
            }

            // ***Trace 300
            if (IsConnected)
            {
                // Note: Using a method as argument:
                // This method calls _bitmexApiSocketService.Subscribe, which requires a 
                // BitmexApiSubscriptionInfo (which is an abstract class) as parameter.
                // This function passes methods such as 
                // BitmetSocketSubscriptions.CreateInstrumentSubsription, which 
                // returns such BitmexApiSubscriptionInfo as parameter.

                // CreateInstrumentSubsription creates an Action delegate that calls the below lambda function.
                // The below 'message' represents the parameter that will be passed to the lambda function.
                // It is a BitmexSocketDataMessage containing the action and data.

                // Files visited for each subscription:
                // This file > BitmetSocketSubscriptions > BitmexApiSubscriptionInfo >
                // BitmexApiSocketService > SocketSubscriptionMessage > SocketMessage
                
                // Filter subscription on symbol (messages received from the exchange will only
                // include data for "XBTUSD").
                string symbolFilter = "XBTUSD";
                _bitmexApiSocketService.Subscribe(symbolFilter, BitmetSocketSubscriptions.CreateInstrumentSubsription(
                    async message =>
                    {
                        // This code runs as 'event handler' when an 'instrument' message is received
                        log.LogInformation("Data received from exchange.");
                    })
                );

                // Loop for 15 seconds to give the exchage enough time to start responding
                var startTime = DateTime.UtcNow;
                while (DateTime.UtcNow - startTime < TimeSpan.FromSeconds(15))
                {
                }

            }

            return "OK";
        }

    }
}
