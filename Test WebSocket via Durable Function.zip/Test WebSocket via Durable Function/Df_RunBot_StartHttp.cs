using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace func_rbk_test_dev_back
{
    public class Df_RunBot_StartHttp
    {
        // IDurableClient can handle both Orchestration and Entity functions
        [FunctionName(nameof(Df_RunBot_StartHttp))]
        public async Task<HttpResponseMessage> HttpStart(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")]HttpRequestMessage req,
            [OrchestrationClient]DurableOrchestrationClient starter,
            ILogger log)
        {
            // Note: Test for GET or POST request: github.com/cmeiklejohn/DurableFunctionDatabase/blob/master/DurableFunctionDatabase/Database.cs
            // Function input comes from the request content.
            string instanceId = await starter.StartNewAsync("Df_RunBot_Orc", null);

            log.LogInformation($"Started orchestration with ID = '{instanceId}'.");

            return starter.CreateCheckStatusResponse(req, instanceId);
        }
    }
}