using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace func_rbk_test_dev_back
{
    public class Df_RunBot_Orc
    {
        [FunctionName(nameof(Df_RunBot_Orc))]
        public async Task<string> RunOrchestrator(
            [OrchestrationTrigger] DurableOrchestrationContext context, ILogger log)
        {
            try
            {
                // The following fields must be received from the client:
                string _key     = "tF5EUoGzId2Oy_Scuv_J-Qta";
                string _secret  = "SWvUwMeILehscmZ8BRnk4gULrtQ5a7TMy4DnXoDKAwz9zYSk";
                string _bitmexEnvironment = "Test";
                
                // Test required parameters. 
                // Although IsNullOrWhiteSpace also tests for trimmed values,
                // rather trim the variables explicitly - in case the user added spaces.
                _key = _key.Trim();
                if (string.IsNullOrWhiteSpace(_key))
                {
                    throw new ArgumentException("The key parameter was not received.");
                }

                _secret = _secret.Trim();
                if (string.IsNullOrWhiteSpace(_secret))
                {
                    throw new ArgumentException("The secret parameter was not received.");
                }

                _bitmexEnvironment = _bitmexEnvironment.Trim();
                if (string.IsNullOrWhiteSpace(_bitmexEnvironment))
                {
                    throw new ArgumentException("The bitmexEnvironment parameter was not received.");
                }

                // Set parameter tuple
                var valueTuple  = (key: _key, secret: _secret, bitmexEnvironment: _bitmexEnvironment);

                // Create a WebSocket Object
                string result = await context.CallActivityAsync<string>("Df_RunBot_BitmexWebSocket_Act", valueTuple);

                log.LogInformation("Orchestrator function exiting.");
                return "ok";
            }
            catch (Exception ex)
            {
                string error_msg = "Error in function: " + context.ToString() + "Message: " + ex.ToString();
                log.LogError(error_msg);
                return "error";
            }
        }
    }
}